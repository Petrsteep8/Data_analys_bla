﻿using FlightService.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Logging
builder.Logging.ClearProviders();
builder.Logging.AddConsole();

// Configuration
var conn = builder.Configuration.GetConnectionString("DefaultConnection");

// Add DbContext with NetTopologySuite for PostGIS
builder.Services.AddDbContext<AppDbContext>(options => options.UseNpgsql(conn, o => o.UseNetTopologySuite()));

// Controllers, swagger, healthchecks
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Healthchecks - DB
object value = builder.Services.AddHealthChecks().AddNpgSql(conn, name: "postgres");

// CORS - allow frontend origin(s)
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowLocal", policy =>
    {
        policy
            .AllowAnyOrigin()
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});

var app = builder.Build();

// global exception handler (simple)
app.UseExceptionHandler("/error");

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseRouting();
app.UseCors("AllowLocal");
app.UseAuthorization();

app.MapControllers();
app.MapHealthChecks("/health");

app.Run();

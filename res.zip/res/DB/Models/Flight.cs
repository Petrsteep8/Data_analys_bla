﻿using NetTopologySuite.Geometries;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FlightService.Models
{
    public class Flight
    {
        public int Id { get; set; }

        [MaxLength(200)]
        public string FlightId { get; set; } = string.Empty;

        [MaxLength(200)]
        public string DroneType { get; set; } = string.Empty;

        [Required]
        public DateTime StartTime { get; set; }

        [Required]
        public DateTime EndTime { get; set; }

        // вычисляемое поле
        [NotMapped]
        public double DurationMinutes => (EndTime - StartTime).TotalMinutes;

        // Географические точки (PostGIS)
        public Point? StartPoint { get; set; }
        public Point? EndPoint { get; set; }

        // Пока хранится как строка, позже заменить ссылкой на regions table
        [MaxLength(200)]
        public string Region { get; set; } = string.Empty;

        // Вспомогательные поля хранения raw-данных (опционально)
        public string? RawMessage { get; set; }
    }
}

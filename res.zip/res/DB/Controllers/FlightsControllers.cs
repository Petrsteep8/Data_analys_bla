﻿using System.Globalization;
using CsvHelper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FlightService.Data;
using FlightService.Models;
using NetTopologySuite.Geometries;

namespace FlightService.Controllers
{
    [ApiController]
    [Route("api")]
    public class FlightsController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly ILogger<FlightsController> _logger;
        private readonly GeometryFactory _geometryFactory;

        public FlightsController(AppDbContext context, ILogger<FlightsController> logger)
        {
            _context = context;
            _logger = logger;
            _geometryFactory = NetTopologySuite.NtsGeometryServices.Instance.CreateGeometryFactory(srid: 4326);
        }

        // POST /api/flights/upload
        // Принимает JSON-массив Flight или CSV (multipart/form-data, поле file)
        [HttpPost("flights/upload")]
        public async Task<IActionResult> UploadFlights([FromBody] List<Flight>? flightsJson)
        {
            if (flightsJson != null && flightsJson.Any())
            {
                return await InsertFlightsBatch(flightsJson);
            }

            if (!Request.HasFormContentType)
                return BadRequest("Ожидался JSON массив или multipart form с файлом CSV (поле 'file').");

            var form = await Request.ReadFormAsync();
            var file = form.Files.GetFile("file");
            if (file == null)
                return BadRequest("CSV файл не найден в form-data (имя поля = file).");

            var flightsFromCsv = new List<Flight>();
            using (var stream = file.OpenReadStream())
            using (var reader = new StreamReader(stream))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var records = csv.GetRecords<dynamic>();
                foreach (var rec in records)
                {
                    try
                    {
                        var r = (IDictionary<string, object>)rec;
                        string flightId = r.ContainsKey("FlightId") ? r["FlightId"]?.ToString() ?? "" : "";
                        string droneType = r.ContainsKey("DroneType") ? r["DroneType"]?.ToString() ?? "" : "";
                        DateTime start = DateTime.Parse(r["StartTime"]?.ToString() ?? throw new Exception("StartTime missing"));
                        DateTime end = DateTime.Parse(r["EndTime"]?.ToString() ?? throw new Exception("EndTime missing"));
                        double startLat = double.Parse(r["StartLat"]?.ToString() ?? "0", CultureInfo.InvariantCulture);
                        double startLon = double.Parse(r["StartLon"]?.ToString() ?? "0", CultureInfo.InvariantCulture);
                        double endLat = double.Parse(r["EndLat"]?.ToString() ?? "0", CultureInfo.InvariantCulture);
                        double endLon = double.Parse(r["EndLon"]?.ToString() ?? "0", CultureInfo.InvariantCulture);
                        string region = r.ContainsKey("Region") ? r["Region"]?.ToString() ?? "" : "";

                        var flight = new Flight
                        {
                            FlightId = flightId,
                            DroneType = droneType,
                            StartTime = start,
                            EndTime = end,
                            StartPoint = _geometryFactory.CreatePoint(new Coordinate(startLon, startLat)),
                            EndPoint = _geometryFactory.CreatePoint(new Coordinate(endLon, endLat)),
                            Region = region
                        };
                        flightsFromCsv.Add(flight);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning("Пропущена строка из-за ошибки парсинга: {err}", ex.Message);
                        continue;
                    }
                }
            }

            return await InsertFlightsBatch(flightsFromCsv);
        }

        // Вставка пакета полётов с валидацией и транзакцией
        private async Task<IActionResult> InsertFlightsBatch(List<Flight> flights)
        {
            if (flights == null || flights.Count == 0)
                return BadRequest("Нет данных для вставки.");

            var toInsert = new List<Flight>();
            foreach (var f in flights)
            {
                if (f.StartTime == default || f.EndTime == default) continue;
                if (f.EndTime <= f.StartTime) continue;
                toInsert.Add(f);
            }

            if (!toInsert.Any())
                return BadRequest("Все записи оказались некорректными.");

            using var tx = await _context.Database.BeginTransactionAsync();
            try
            {
                await _context.Flights.AddRangeAsync(toInsert);
                await _context.SaveChangesAsync();
                await tx.CommitAsync();
                return Ok(new { Inserted = toInsert.Count });
            }
            catch (Exception ex)
            {
                await tx.RollbackAsync();
                _logger.LogError(ex, "Ошибка при вставке данных");
                return StatusCode(500, "Внутренняя ошибка сервера при вставке данных.");
            }
        }

        // GET /api/statistics/region
        [HttpGet("statistics/region")]
        public async Task<IActionResult> GetFlightsByRegion()
        {
            var stats = await _context.Flights
                .GroupBy(f => f.Region)
                .Select(g => new { Region = g.Key, Count = g.Count() })
                .OrderByDescending(x => x.Count)
                .ToListAsync();

            return Ok(stats);
        }

        // GET /api/statistics/daily
        [HttpGet("statistics/daily")]
        public async Task<IActionResult> GetFlightsByDay()
        {
            var stats = await _context.Flights
                .GroupBy(f => f.StartTime.Date)
                .Select(g => new { Date = g.Key, Count = g.Count() })
                .OrderBy(x => x.Date)
                .ToListAsync();

            return Ok(stats);
        }

        // GET /api/statistics/top10
        [HttpGet("statistics/top10")]
        public async Task<IActionResult> GetTop10Regions()
        {
            var stats = await _context.Flights
                .GroupBy(f => f.Region)
                .Select(g => new { Region = g.Key, Count = g.Count() })
                .OrderByDescending(x => x.Count)
                .Take(10)
                .ToListAsync();

            return Ok(stats);
        }

        // GET /api/statistics/metrics
        [HttpGet("statistics/metrics")]
        public async Task<IActionResult> GetGeneralMetrics()
        {
            var q = _context.Flights.AsQueryable();
            var totalFlights = await q.CountAsync();
            if (totalFlights == 0) return Ok(new { Message = "Нет данных" });

            var avgDuration = await q.AverageAsync(f => (f.EndTime - f.StartTime).TotalMinutes);
            var peak = await q
                .GroupBy(f => new { f.StartTime.Date, f.StartTime.Hour })
                .Select(g => g.Count())
                .OrderByDescending(c => c)
                .FirstOrDefaultAsync();

            var minDate = await q.MinAsync(f => f.StartTime.Date);
            var maxDate = await q.MaxAsync(f => f.StartTime.Date);
            var daysRange = (maxDate - minDate).Days + 1;
            var distinctFlightDays = await q.Select(f => f.StartTime.Date).Distinct().CountAsync();
            var zeroDays = daysRange - distinctFlightDays;

            var metrics = new
            {
                TotalFlights = totalFlights,
                AvgDurationMinutes = Math.Round(avgDuration, 2),
                PeakHourFlights = peak,
                ZeroDays = zeroDays,
                DaysRange = daysRange
            };
            return Ok(metrics);
        }

        // GET /api/flights/{id}
        [HttpGet("flights/{id:int}")]
        public async Task<IActionResult> GetFlightById(int id)
        {
            var flight = await _context.Flights.FindAsync(id);
            if (flight == null) return NotFound();
            return Ok(flight);
        }

        // GET /api/flights (с пагинацией)
        [HttpGet("flights")]
        public async Task<IActionResult> GetFlights([FromQuery] int page = 1, [FromQuery] int pageSize = 100)
        {
            page = Math.Max(1, page);
            pageSize = Math.Clamp(pageSize, 1, 1000);
            var skip = (page - 1) * pageSize;
            var data = await _context.Flights
                .OrderByDescending(f => f.StartTime)
                .Skip(skip).Take(pageSize)
                .ToListAsync();
            return Ok(data);
        }
    }
}

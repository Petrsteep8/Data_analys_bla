﻿using FlightService.Models;
using Microsoft.EntityFrameworkCore;
using NetTopologySuite.Geometries;

namespace FlightService.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Flight> Flights { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Flight>(eb =>
            {
                eb.ToTable("flights");
                eb.HasKey(f => f.Id);
                eb.Property(f => f.FlightId).HasMaxLength(200);
                // Spatial column types
                eb.Property(f => f.StartPoint).HasColumnType("geometry (Point, 4326)");
                eb.Property(f => f.EndPoint).HasColumnType("geometry (Point, 4326)");
                // GiST index for spatial queries
                eb.HasIndex(f => f.StartPoint).HasMethod("GIST");
                eb.HasIndex(f => f.EndPoint).HasMethod("GIST");

                // index for quick region/stat queries
                eb.HasIndex(f => f.Region);
                // unique-ish dedupe candidate (FlightId if present)
                eb.HasIndex(f => f.FlightId).IsUnique(false);
            });
        }
    }
}

from collections import defaultdict
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import re
from datetime import datetime
import numpy as np


def flights_count(df_no_nan):
    regions = df_no_nan['Центр ЕС ОрВД'].value_counts()
    new_df = pd.DataFrame(regions)
    new_df = new_df.sort_values('count')
    new_df.to_csv('Flights_cnt.csv', sep='\t', encoding='utf-8')
    plt.figure(figsize=(14, 10))
    ax = sns.barplot(
        data=new_df,
        x="Центр ЕС ОрВД",
        y="count",
        color='green'
    )

    for i, count in enumerate(new_df['count']):
        ax.text(i, count + 0.5, str(count),
                ha='center', va='bottom', fontsize=10, fontweight='bold')

    plt.xticks(
        rotation=45,
        ha='right',
        fontsize=10
    )
    plt.title('Количество полетов БПЛА по регионам')
    plt.ylabel('Количество полетов')
    plt.xlabel('Регионы')
    plt.tight_layout()
    plt.show()


def flights_duration(df_no_nan):
    region_durations = {}
    for index, row in df_no_nan.iterrows():
        region = row['Центр ЕС ОрВД']
        dep_info = row['DEP']
        arr_info = row['ARR']
        atd_match = re.search(r'-ATD\s+(\d{4})', str(dep_info))
        atd_time = atd_match.group(1) if atd_match else None
        ata_match = re.search(r'-ATA\s+(\d{4})', str(arr_info))
        ata_time = ata_match.group(1) if ata_match else None
        if atd_time and ata_time:
            atd_dt = datetime.strptime(atd_time, '%H%M')
            ata_dt = datetime.strptime(ata_time, '%H%M')
            time_diff = (ata_dt - atd_dt).total_seconds() / 60
            if time_diff < 0:
                time_diff += 24 * 60
            if region not in region_durations:
                region_durations[region] = []
            region_durations[region].append(time_diff)
    reg_dur = {key: sum(values) // len(values) for key, values in region_durations.items()}
    sl = {
        'Центр ЕС ОрВД': [key for key, values in reg_dur.items()],
        'Средняя длительность полёта': [values for key, values in reg_dur.items()]
    }
    new_df = pd.DataFrame(sl)
    new_df = new_df.sort_values('Средняя длительность полёта')
    new_df.to_csv('Flights_duration.csv', sep='\t', encoding='utf-8')
    plt.figure(figsize=(14, 10))
    sns.barplot(
        data=new_df,
        x="Центр ЕС ОрВД",
        y="Средняя длительность полёта",
        color='blue',
        orient='h'
    )
    plt.xticks(
        rotation=45,
    )
    plt.title('Средняя длительность полёта по регионам')
    plt.ylabel('Средняя длительность полёта (в мин.)')
    plt.xlabel('Регионы')
    plt.tight_layout()
    plt.show()


def calculate_monthly_flight_dynamics(df):
    monthly_flights = defaultdict(int)
    flight_details = []
    for index, row in df.iterrows():
        region = row['Центр ЕС ОрВД']
        shr_content = str(row['SHR'])
        dof_match = re.search(r'DOF/(\d{6})', shr_content)
        if dof_match:
            dof_str = dof_match.group(1)
            year = int(dof_str[:2]) + 2000
            month = int(dof_str[2:4])
            day = int(dof_str[4:6])
            try:
                flight_date = datetime(year, month, day)
                month_year = flight_date.strftime("%Y-%m")
                typ_match = re.search(r'TYP/([A-Z]+)', shr_content)
                aircraft_type = typ_match.group(1) if typ_match else "Unknown"
                reg_match = re.search(r'REG/([A-Z0-9,-]+)', shr_content)
                registration = reg_match.group(1) if reg_match else "Unknown"
                opr_match = re.search(r'OPR/([^\\s)]+)', shr_content)
                operator = opr_match.group(1) if opr_match else "Unknown"
                monthly_flights[month_year] += 1
                flight_details.append({
                    'Region': region,
                    'Date': flight_date,
                    'MonthYear': month_year,
                    'AircraftType': aircraft_type,
                    'Registration': registration,
                    'Operator': operator
                })

            except ValueError as e:
                print(f"Ошибка преобразования даты {dof_str}: {e}")
                continue

    details_df = pd.DataFrame(flight_details)
    details_df.to_csv('Monthly_flights_dynamics.csv', sep='\t', encoding='utf-8')
    return dict(monthly_flights), details_df


def plot_monthly_dynamics(monthly_flights, details_df):
    sorted_months = sorted(monthly_flights.keys())
    counts = [monthly_flights[month] for month in sorted_months]
    fig, (ax2, ax3) = plt.subplots(1, 2, figsize=(16, 6))
    bars = ax2.bar(sorted_months, counts, color=plt.cm.viridis(np.linspace(0, 1, len(sorted_months))))
    ax2.set_xlabel('Месяц', fontsize=12, fontweight='bold')
    ax2.set_ylabel('Количество полетов', fontsize=12, fontweight='bold')
    ax2.set_title('Распределение полетов по месяцам', fontsize=14, fontweight='bold')
    ax2.tick_params(axis='x', rotation=45)
    ax2.grid(True, alpha=0.3, axis='y')
    for bar, count in zip(bars, counts):
        height = bar.get_height()
        ax2.text(bar.get_x() + bar.get_width() / 2., height + 0.1,
                 str(count), ha='center', va='bottom', fontweight='bold')
    if not details_df.empty:
        type_counts = details_df['AircraftType'].value_counts()
        ax3.pie(type_counts.values, labels=type_counts.index, autopct='%1.1f%%',
                startangle=45, colors=plt.cm.Set3(range(len(type_counts))))
        ax3.set_title('Распределение по типам воздушных судов', fontsize=14, fontweight='bold')

    plt.tight_layout()
    plt.show()

    return sorted_months, counts


def main():
    df = pd.read_excel('datasets/2025.xlsx')
    df_no_nan = df.dropna()
    flights_count(df_no_nan)
    flights_duration(df_no_nan)
    monthly_flights, details_df = calculate_monthly_flight_dynamics(df_no_nan)
    print(plot_monthly_dynamics(monthly_flights, details_df))


if __name__ == '__main__':
    main()
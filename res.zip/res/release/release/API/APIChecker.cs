﻿using Serilog;

internal class APIChecker
{
    public static async Task CheckAPI(HttpContext context)
    {
        var request = context.Request;
        var responce = context.Response;
        var path = request.Path;

        if (path == "/api/statistics/region" && request.Method == "GET")
        {
            responce.ContentType = "image/jpg";
            try
            {
                responce.StatusCode = 200;
                await responce.SendFileAsync("photos/region.jpg");
            } catch (Exception ex)
            {
                
                responce.StatusCode = 500;
            }
        }
        else if (path == "/api/statistics/mounthly" && request.Method == "GET")
        {
            responce.ContentType = "image/jpg";
            try
            {
                responce.StatusCode = 200;
                await responce.SendFileAsync("photos/mounthly.jpg");
            }
            catch (Exception ex)
            {
                responce.StatusCode = 500;
            }
        }
        else if (path == "/api/statistics/duration" && request.Method == "GET")
        {
            responce.ContentType = "image/jpg";
            try
            {
                responce.StatusCode = 200;
                await responce.SendFileAsync("photos/duration.jpg");
            }
            catch (Exception ex)
            {
                responce.StatusCode = 500;
            }
        }
        else if (path == "/api/flights/upload" && request.Method == "POST")
        {
            IFormFileCollection files = request.Form.Files;
            var uploadPath = $"{Directory.GetCurrentDirectory()}/photos";
            if (!Directory.Exists(uploadPath))
            {
                Directory.CreateDirectory(uploadPath);
            }

            foreach (var file in files)
            {
                string fullPath = $"{uploadPath}/{file.FileName}";
                var fileStream = new FileStream(fullPath, FileMode.Create);
                await file.CopyToAsync(fileStream);
            }
        }
        else if ((path == "/" || path == "/main") && request.Method == "GET")
        {
            responce.ContentType = "text/html; charset=utf-8";
            responce.StatusCode = 200;
            await responce.SendFileAsync("html/index.html");
        }
        else
        {
            responce.ContentType = "text/html; charset=utf-8";
            responce.StatusCode = 404;
            await responce.WriteAsync("Page not found!");
        }
    }
}